#!/usr/bin/with-contenv bash

chown -R www-data:www-data /var/www/.env.local
